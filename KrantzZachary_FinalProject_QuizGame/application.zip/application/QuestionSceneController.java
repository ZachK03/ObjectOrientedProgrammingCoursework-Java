package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class QuestionSceneController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	private ArrayList<Question> gameData = new ArrayList<Question>();
	private String username;
	private String selectedAnswer;
	private int gameScore = 0;
	private Queue<LocalDateTime> timeStamps = new LinkedList<>();
	private Queue<Boolean> answerData = new LinkedList<>();
	
	@FXML Label nameLabel;
	@FXML Label pointsLabel;
	@FXML Label timerLabel;
	@FXML Label object1Label;
	@FXML Label object2Label;
	@FXML Button answerButton1;
	@FXML Button answerButton2;
	@FXML Button answerButton3;
	@FXML Button answerButton4;
	@FXML Label correctLabel;
	@FXML Label incorrectLabel;
	
	public void selectAnswer(ActionEvent event) {
		selectedAnswer = ((Button)event.getSource()).getText();
	}
	
	public void updateUsername(String name) {
		nameLabel.setText("User: " + name);
		this.username = name;
	}
	
	public void setObjectText(String o1, String o2) {
		object1Label.setText(o1);
		object2Label.setText(o2);
	}
	
	public void setAnswerOptions(String o1, String o2, String o3, String o4) {
		answerButton1.setText(o1);
		answerButton2.setText(o2);
		answerButton3.setText(o3);
		answerButton4.setText(o4);
	}
	
	public void getGameData() throws IOException {
		String filePath = new File("").getAbsolutePath();
		filePath += "\\src\\application\\input.txt";
		FileReader file = new FileReader(filePath);
	    BufferedReader reader = new BufferedReader(file);
	    String line = "";
	    String[] objects;
	    String[] answers;
	    while((line = reader.readLine()) != null) {
	    	objects = line.split(" ");
	    	line = reader.readLine();
	    	answers = line.split(" ");
	    	Question question = new Question(objects[0],objects[1],answers[0],answers[1],answers[2],answers[3]);
	    	gameData.add(question);
	    }
	    reader.close();
	}
	
	public void initGame() {
		try {
			getGameData();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Thread gameThread = new Thread(this::startGame);
		gameThread.setDaemon(true);
		gameThread.start();
	}
	
	public void startGame() {
		System.out.println("Game starting...");
		hideCorrectNotification();
		try {
			startQuestionTimer();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(gameData.size() == 0) {
			//Switch to end screen, create error popup
			return;
		};
		
		for(Question q : gameData) {
			System.out.println(q);
			selectedAnswer = null;
			Platform.runLater(()->{
				hideAnswer();
			});
			String[] objects = q.getObjectsAdded();
			Platform.runLater(()->{
				setObjectText(objects[0],objects[1]);
			});
			String[] answers = q.getAnswerOptions();
			Platform.runLater(()->{
				setAnswerOptions(answers[0],answers[1],answers[2],answers[3]);
			});
			try {
				startQuestionTimer();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			handleAnswer(q);
			Platform.runLater(()->{
				showAnswer(q);
				updateScoreDisplay();
			});
			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			hideCorrectNotification();
		}
		System.out.println("Game ended.");
		Platform.runLater(()->{
			try {
				gameEndSwitchScene();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}
	
	public void gameEndSwitchScene() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("EndScene.fxml"));
		root = loader.load();
		
		EndSceneController controller = loader.getController();
		stage = (Stage)((Node)nameLabel).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		controller.initScene(timeStamps,answerData,gameScore,username);
	}
	
	public void startQuestionTimer() throws InterruptedException {
		for(int i = 5; i >= 0; i--) {
			final String timerNum = String.valueOf(i);
			Platform.runLater(() -> {
				timerLabel.setText(timerNum);
			});
			Thread.sleep(1000);
		}
	}
	
	public void handleAnswer(Question current) {
		timeStamps.offer(LocalDateTime.now());
		if(selectedAnswer == null) {
			answerData.offer(false);
			showCorrectNotification(false);
			return;
		};
		if(selectedAnswer == current.getCorrectAnswer()) {
			gameScore++;
			answerData.offer(true);
			showCorrectNotification(true);
			return;
		};
		answerData.offer(false);
		showCorrectNotification(false);
	}
	
	public void showCorrectNotification(boolean correct) {
		if(correct) {
			correctLabel.setVisible(true);
		} else {
			incorrectLabel.setVisible(true);
		}
	}
	
	public void hideCorrectNotification() {
		correctLabel.setVisible(false);
		incorrectLabel.setVisible(false);
	}
	
	public void updateScoreDisplay() {
		pointsLabel.setText(String.valueOf(gameScore) + " Points");
	}
	
	public void showAnswer(Question q) {
		String correctAnswer = q.getCorrectAnswer();
		Button[] buttons = {answerButton1,answerButton2,answerButton3,answerButton4};
		for(Button b : buttons) {
			String answer = b.getText();
			if(answer == correctAnswer) {
				b.setTextFill(Color.GREEN);
			} else {
				b.setTextFill(Color.RED);
			}
		}
	}
	
	public void hideAnswer() {
		Button[] buttons = {answerButton1,answerButton2,answerButton3,answerButton4};
		for(Button b : buttons) {
			b.setTextFill(Color.BLACK);
		}
	}
}
