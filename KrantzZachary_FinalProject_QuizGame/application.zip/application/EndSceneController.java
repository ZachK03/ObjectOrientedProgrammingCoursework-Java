package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Stack;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class EndSceneController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	private int gameScore;
	private String username;
	
	@FXML Label timeStampLabel;
	@FXML Label questionAmountLabel;
	@FXML Label percentageLabel;
	
	public void initScene(Queue<LocalDateTime> timeStamps,Queue<Boolean> answerData,int gs,String name) {
		this.gameScore = gs;
		this.username = name;
		displayTotalScore(answerData,gs);
		displayTimeStamps(timeStamps,answerData);
		saveScoreToDatabase();
	}
	
	public void displayTimeStamps(Queue<LocalDateTime> timeStamps,Queue<Boolean> answerData) {
		String displayTimeStamps = "";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		int i = 1;
		while(!timeStamps.isEmpty()) {
			LocalDateTime time = timeStamps.poll();
			Boolean isCorrect = answerData.poll();
			displayTimeStamps += "Question " + i + ": ";
			if(isCorrect) {
				displayTimeStamps += "Correct\n";
			} else {
				displayTimeStamps += "Incorrect\n";
			};
			displayTimeStamps += (dtf.format(time)) + "\n";
			i++;
		}
		timeStampLabel.setText(displayTimeStamps);
	}
	
	public void displayTotalScore(Queue<Boolean> answerData, int score) {
		int size = answerData.size();
		int percent = (int)((score*100.0f)/size);
		
		questionAmountLabel.setText(String.valueOf(score) + "/" + String.valueOf(size));
		percentageLabel.setText(String.valueOf(percent) + "%");
	}
	
	public void saveScoreToDatabase() {
		System.out.println("Saving game session to database.");
		try {
			String filePath = new File("").getAbsolutePath();
			filePath += "\\src\\application\\savedGameScore.txt";
			File file = new File(filePath);
			if(file.createNewFile()) {
				//New file created
				FileWriter write = new FileWriter(filePath);
				write.write(username + " " + String.valueOf(gameScore) + "\n");
				write.close();
			} else {
				//File found, modify current data
				updateDatabase(filePath,file);
			}
		} catch (IOException e) {
			e.printStackTrace();
		};
	}
	
	public void updateDatabase(String path, File mainFile) throws IOException {
		String line = "";
		FileReader file = new FileReader(path);
	    BufferedReader reader = new BufferedReader(file);
	    ArrayList<String> scores = new ArrayList<>();
	    int i = 0;
	    boolean isAdded = false;
		while((line = reader.readLine()) != null && i < 10) {
			if(line == "") {
				scores.add(username + " " + String.valueOf(gameScore) + "\n");
				break;
			};
			String[] score = line.split(" ");
			String name = score[0];
			int scoreNum = Integer.parseInt(score[1]);
			if(scoreNum < gameScore && !isAdded) {
				scores.add(username + " " + String.valueOf(gameScore) + "\n");
				isAdded = true;
				i++;
			}
			scores.add(name + " " + String.valueOf(scoreNum) + "\n");
			i++;
		}
		if(!isAdded && i < 10) {
			scores.add(username + " " + String.valueOf(gameScore) + "\n");
		}
		
		String filePath = new File("").getAbsolutePath();
		filePath += "\\src\\application\\savedGameScoreTemp.txt";
		File tempFile = new File(filePath);
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		for(String s : scores) {
			writer.write(s);
		}
		
		writer.close();
		reader.close();
		mainFile.delete();
		mainFile = new File(path);
		tempFile.renameTo(mainFile);
	}
	
	public void generateReport() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Info: Generated Report");
		try {
			alert.setContentText(getScoreData());
		} catch (IOException e) {
			e.printStackTrace();
		};
		alert.show();
		System.out.println("Report displayed.");
	}
	
	public String getScoreData() throws IOException {
		System.out.println("Fetching database info...");
		String out = "Top 10 Scores:\n";
		String filePath = new File("").getAbsolutePath();
		filePath += "\\src\\application\\savedGameScore.txt";
		FileReader file = new FileReader(filePath);
	    BufferedReader reader = new BufferedReader(file);
	    String line = "";
	    while((line = reader.readLine()) != null) {
	    	String[] score = line.split(" ");
	    	out += score[0] + " : " + score[1] + "\n";
	    }
	    reader.close();
	    System.out.println("Database info retrieved.");
		return out;
	};
	
	class GameScore {
		public String name;
		public int score;
		
		public GameScore(String n, int s) {
			this.name = n;
			this.score = s;
		}
	}
}
