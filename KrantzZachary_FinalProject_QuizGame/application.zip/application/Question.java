package application;

public class Question {
	private String[] objectsAdded = new String[2];
	private String[] answerOptions = new String[4];
	private String correctAnswer;
	
	public Question(String o1, String o2, String a1, String a2, String a3, String a4) {
		this.objectsAdded[0] = o1;
		this.objectsAdded[1] = o2;
		
		this.answerOptions[0] = a1;
		this.answerOptions[1] = a2;
		this.answerOptions[2] = a3;
		this.answerOptions[3] = a4;
		
		this.correctAnswer = a1;
	}

	public String[] getObjectsAdded() {
		return objectsAdded;
	}

	public void setObjectsAdded(String[] objectsAdded) {
		this.objectsAdded = objectsAdded;
	}

	public String[] getAnswerOptions() {
		return answerOptions;
	}

	public void setAnswerOptions(String[] answerOptions) {
		this.answerOptions = answerOptions;
	}

	public String getCorrectAnswer() {
		return correctAnswer;
	}
	
	public String toString() {
		String out = "";
		out += "Question: ";
		for(String s : objectsAdded) {
			out += s + " ";
		}
		out += "Answers: ";
		for(String s : answerOptions) {
			out += s + " ";
		}
		out += "Correct answer: " + correctAnswer;
		return out;
	}
	
}
